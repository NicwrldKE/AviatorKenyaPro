# Deploying Aviator Pro on aaPanel

This guide will help you deploy the Aviator Pro application on your aaPanel server.

## Prerequisites

1.  **aaPanel Installed:** Ensure you have aaPanel installed on your VPS.
2.  **Node.js Manager:** Go to the aaPanel App Store and install the **"Node.js Version Manager"**.
    *   Install **Node.js v20** (or latest LTS) inside the manager.

## Step 1: Prepare the Files

1.  On your local machine (or Replit), open the **Shell**.
2.  Run the build command to generate the production files:
    ```bash
    npm run build
    ```
3.  This will create a `dist/` folder.
4.  You need to upload the following files/folders to your aaPanel server (e.g., in `/www/wwwroot/aviator-pro`):
    *   `dist/` (The built application)
    *   `package.json` (Dependency list)
    *   `ecosystem.config.js` (PM2 configuration)

    *Note: You do NOT need to upload `client/`, `server/`, or `node_modules/`. The `dist/` folder contains everything needed.*

## Step 2: Upload to aaPanel

1.  Login to aaPanel.
2.  Go to **Files**.
3.  Create a directory: `/www/wwwroot/aviator-pro`.
4.  Upload the files from Step 1 into this directory.

## Step 3: Install Dependencies

1.  In aaPanel, open the **Terminal** (or SSH into your server).
2.  Navigate to your folder:
    ```bash
    cd /www/wwwroot/aviator-pro
    ```
3.  Install production dependencies:
    ```bash
    npm install --production
    ```

## Step 4: Start the Application (Node.js Project)

1.  Go to **Website** > **Node Project** (tab) in aaPanel.
2.  Click **Add Node Project**.
3.  Fill in the details:
    *   **Project Directory:** `/www/wwwroot/aviator-pro`
    *   **Run Command:** Custom Command -> `npm run start` OR Select `ecosystem.config.js` if available.
    *   **Port:** `5000`
    *   **Node Version:** Select v20.
4.  Click **Submit**.

## Step 5: Map Domain (Reverse Proxy)

1.  Once the project is running, click **Mapping** (or "Map Domain") in the Node Project list.
2.  Enter your domain name (e.g., `aviator-kenya.com`).
3.  aaPanel will automatically set up Nginx to forward traffic from port 80/443 to port 5000.

## Step 6: SSL (HTTPS)

1.  Go to the **Website** > **PHP Project** (Your mapped domain will appear here).
2.  Click **Conf** > **SSL**.
3.  Select **Let's Encrypt**.
4.  Click **Apply** to get a free HTTPS certificate.

## Troubleshooting

*   **App not starting?** Check the logs in the Node Project manager.
*   **Admin Panel:** Access the admin panel at `https://your-domain.com/predictor-admin`.
*   **Database:** This version uses in-memory storage (simulated). For a real database, you would need to configure PostgreSQL in `server/db.ts` and providing `DATABASE_URL` in the environment variables.
