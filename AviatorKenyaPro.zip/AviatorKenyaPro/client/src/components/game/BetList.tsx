import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useEffect, useState } from "react";

interface Bet {
  user: string;
  amount: number;
  cashoutMult?: number;
  profit?: number;
  isHighRoller?: boolean;
}

interface BetListProps {
  bets: Bet[];
  maxItems?: number;
}

export function BetList({ bets, maxItems = 20 }: BetListProps) {
  // Sort: Cashed out on top (green), then active
  const sortedBets = [...bets].sort((a, b) => {
    if (a.cashoutMult && !b.cashoutMult) return -1;
    if (!a.cashoutMult && b.cashoutMult) return 1;
    return b.amount - a.amount; // High bets on top if status is same
  });

  return (
    <div className="space-y-1 w-full">
      <div className="flex justify-between px-2 py-1 text-[10px] font-bold text-muted-foreground uppercase tracking-wider border-b border-white/5">
        <span>User</span>
        <div className="flex gap-4">
          <span>Bet</span>
          <span className="w-12 text-right">Mult.</span>
        </div>
      </div>
      
      <div className="space-y-0.5">
        {sortedBets.slice(0, maxItems).map((bet, i) => (
          <div 
            key={i} 
            className={cn(
              "flex justify-between items-center text-xs font-mono py-1.5 px-2 rounded transition-all duration-300",
              bet.cashoutMult 
                ? "bg-green-500/10 text-green-400 border border-green-500/20 shadow-[0_0_10px_rgba(34,197,94,0.1)]" 
                : "bg-white/5 text-muted-foreground hover:bg-white/10",
              bet.isHighRoller && !bet.cashoutMult && "border-l-2 border-l-yellow-500 bg-yellow-500/5"
            )}
          >
            <div className="flex items-center gap-2">
              <Avatar className="w-4 h-4 rounded-full">
                 <AvatarFallback className={cn("text-[8px] font-bold", bet.isHighRoller ? "bg-yellow-500 text-black" : "bg-white/10 text-white")}>
                   {bet.user[0]}
                 </AvatarFallback>
              </Avatar>
              <span className={cn("opacity-70", bet.isHighRoller && "text-yellow-500 font-bold")}>
                {bet.user.slice(0, 4)}***{bet.user.slice(-2)}
              </span>
            </div>
            
            <div className="flex gap-4 items-center">
              <span className={cn("font-bold", bet.isHighRoller && "text-yellow-500")}>
                {bet.amount.toLocaleString()}
              </span>
              <div className={cn("w-12 text-right font-bold", bet.cashoutMult ? "text-white bg-green-500 rounded px-1" : "opacity-20")}>
                {bet.cashoutMult ? `${bet.cashoutMult.toFixed(2)}x` : '-'}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
