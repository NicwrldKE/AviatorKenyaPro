import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { cn } from "@/lib/utils";

interface HistoryModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function HistoryModal({ open, onOpenChange }: HistoryModalProps) {
  // Mock History Data
  const history = Array.from({ length: 20 }).map((_, i) => ({
    id: 9000 - i,
    date: new Date(Date.now() - i * 1000 * 60 * 2).toLocaleTimeString(),
    bet: Math.floor(Math.random() * 1000) + 100,
    mult: (Math.random() * 10 + 1).toFixed(2),
    crashed: Math.random() > 0.5,
    cashout: (Math.random() * 5 + 1).toFixed(2)
  }));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-white/10 text-foreground max-w-2xl max-h-[80vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="text-2xl font-display text-primary">Betting History</DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-auto">
          <Table>
            <TableHeader className="bg-black/20 sticky top-0">
              <TableRow className="border-white/10 hover:bg-transparent">
                <TableHead className="text-muted-foreground">Time</TableHead>
                <TableHead className="text-muted-foreground">Bet (KES)</TableHead>
                <TableHead className="text-muted-foreground">Multiplier</TableHead>
                <TableHead className="text-right text-muted-foreground">Profit</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {history.map((row) => {
                const won = !row.crashed || parseFloat(row.cashout) < parseFloat(row.mult);
                const profit = won ? (row.bet * parseFloat(row.cashout)) - row.bet : -row.bet;
                
                return (
                  <TableRow key={row.id} className="border-white/5 hover:bg-white/5">
                    <TableCell className="font-mono text-xs text-muted-foreground">{row.date}</TableCell>
                    <TableCell className="font-mono">{row.bet}</TableCell>
                    <TableCell className="font-mono">
                      <span className={cn(won ? "text-green-500" : "text-red-500")}>
                        {won ? `${row.cashout}x` : "Crashed"}
                      </span>
                    </TableCell>
                    <TableCell className={cn("text-right font-mono font-bold", profit > 0 ? "text-green-500" : "text-white/50")}>
                      {profit > 0 ? "+" : ""}{profit.toFixed(0)}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </DialogContent>
    </Dialog>
  );
}
