import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

interface BetControlsProps {
  gameState: "WAITING" | "FLYING" | "CRASHED";
  onBet: (amount: number, autoCashout: number | null) => void;
  onCashout: () => void;
  currentMultiplier: number;
  hasBet: boolean;
  hasCashedOut: boolean;
}

export function BetControls({ 
  gameState, 
  onBet, 
  onCashout, 
  currentMultiplier,
  hasBet,
  hasCashedOut 
}: BetControlsProps) {
  const [amount, setAmount] = useState(10);
  const [autoCashout, setAutoCashout] = useState<string>("2.00");
  const [autoEnabled, setAutoEnabled] = useState(false);

  const isBettingClosed = gameState === "FLYING" && !hasBet;
  const canCashout = gameState === "FLYING" && hasBet && !hasCashedOut;
  const canBet = gameState === "WAITING" || gameState === "CRASHED";

  const handleAction = () => {
    if (canCashout) {
      onCashout();
    } else if (canBet) {
      onBet(amount, autoEnabled ? parseFloat(autoCashout) : null);
    }
  };

  return (
    <div className="w-full bg-card/80 backdrop-blur-md border-t border-white/10 p-4 md:p-6 md:rounded-t-3xl mt-auto z-30">
      <div className="flex flex-col md:flex-row gap-4 items-stretch max-w-4xl mx-auto">
        
        {/* Bet Inputs */}
        <div className="flex-1 grid grid-cols-2 gap-4 bg-black/20 p-3 rounded-xl border border-white/5">
          <div className="space-y-2">
            <label className="text-xs text-muted-foreground font-ui uppercase font-bold">Bet Amount (KES)</label>
            <div className="relative">
               <Input 
                type="number" 
                value={amount} 
                onChange={(e) => setAmount(Number(e.target.value))}
                className="bg-background/50 border-white/10 text-lg font-mono h-12 text-center"
                data-testid="input-bet-amount"
              />
              <div className="absolute right-0 top-0 bottom-0 flex flex-col justify-center gap-1 pr-1">
                 <button onClick={() => setAmount(amount + 10)} className="w-6 h-5 bg-white/5 hover:bg-white/10 text-[10px] rounded flex items-center justify-center">+</button>
                 <button onClick={() => setAmount(Math.max(0, amount - 10))} className="w-6 h-5 bg-white/5 hover:bg-white/10 text-[10px] rounded flex items-center justify-center">-</button>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button onClick={() => setAmount(20)} className="text-xs bg-white/5 hover:bg-white/10 rounded py-1">20</button>
              <button onClick={() => setAmount(50)} className="text-xs bg-white/5 hover:bg-white/10 rounded py-1">50</button>
              <button onClick={() => setAmount(100)} className="text-xs bg-white/5 hover:bg-white/10 rounded py-1">100</button>
              <button onClick={() => setAmount(500)} className="text-xs bg-white/5 hover:bg-white/10 rounded py-1">500</button>
            </div>
          </div>

          <div className="space-y-2">
             <div className="flex items-center justify-between">
                <label className="text-xs text-muted-foreground font-ui uppercase font-bold">Auto Cashout</label>
                <div 
                  className={cn("w-8 h-4 rounded-full transition-colors cursor-pointer relative", autoEnabled ? "bg-secondary" : "bg-white/10")}
                  onClick={() => setAutoEnabled(!autoEnabled)}
                >
                  <div className={cn("absolute top-0.5 bottom-0.5 w-3 bg-white rounded-full transition-all", autoEnabled ? "left-4.5" : "left-0.5")} />
                </div>
             </div>
             <Input 
                type="number" 
                value={autoCashout} 
                onChange={(e) => setAutoCashout(e.target.value)}
                disabled={!autoEnabled}
                className={cn(
                  "bg-background/50 border-white/10 text-lg font-mono h-12 text-center transition-opacity",
                  !autoEnabled && "opacity-50"
                )}
                step="0.1"
                data-testid="input-auto-cashout"
              />
          </div>
        </div>

        {/* Big Button */}
        <div className="flex-1 md:max-w-[300px]">
          <Button 
            size="lg" 
            onClick={handleAction}
            disabled={isBettingClosed || (canBet && hasBet)} // Disable if waiting for next round after betting
            className={cn(
              "w-full h-full min-h-[80px] text-2xl font-display font-bold uppercase tracking-widest shadow-2xl transition-all transform hover:scale-[1.02] active:scale-[0.98]",
              canCashout 
                ? "bg-secondary hover:bg-secondary/90 text-secondary-foreground shadow-secondary/20 ring-4 ring-secondary/20 animate-pulse" // Cashout State
                : hasBet && gameState === "WAITING"
                  ? "bg-destructive hover:bg-destructive/90 text-white opacity-80" // Cancel Bet State (Simulated as Waiting)
                  : "bg-primary hover:bg-primary/90 text-primary-foreground shadow-primary/20 ring-4 ring-primary/10" // Bet State
            )}
            data-testid="button-main-action"
          >
            <div className="flex flex-col items-center leading-none gap-1">
              {canCashout ? (
                <>
                  <span>CASHOUT</span>
                  <span className="text-lg font-mono opacity-90">
                    {(amount * currentMultiplier).toLocaleString()} KES
                  </span>
                </>
              ) : hasBet && gameState === "WAITING" ? (
                 <>
                  <span>BET PLACED</span>
                  <span className="text-xs font-ui normal-case opacity-80">Waiting for round...</span>
                 </>
              ) : (
                <>
                  <span>BET</span>
                  <span className="text-xs font-ui normal-case opacity-80">Next Round</span>
                </>
              )}
            </div>
          </Button>
        </div>

      </div>
    </div>
  );
}
