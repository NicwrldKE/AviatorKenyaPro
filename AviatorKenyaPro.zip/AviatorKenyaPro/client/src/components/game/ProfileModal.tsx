import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useState } from "react";
import { toast } from "sonner";
import { User, Save } from "lucide-react";

interface ProfileModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ProfileModal({ open, onOpenChange }: ProfileModalProps) {
  const [username, setUsername] = useState("Player_254");
  const [email, setEmail] = useState("");

  const handleSave = () => {
    toast.success("Profile Updated");
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-white/10 text-foreground sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="text-2xl font-display text-primary">Edit Profile</DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div className="flex flex-col items-center gap-4">
            <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center border-2 border-primary/20 relative group cursor-pointer overflow-hidden">
              <User className="w-10 h-10 text-primary group-hover:scale-110 transition-transform" />
              <div className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <span className="text-xs font-bold text-white">CHANGE</span>
              </div>
            </div>
            <p className="text-sm text-muted-foreground">Tap to upload new avatar</p>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Username</Label>
              <Input 
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="bg-black/20 border-white/10"
              />
            </div>
            <div className="space-y-2">
              <Label>Email (Optional)</Label>
              <Input 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="johndoe@example.com"
                className="bg-black/20 border-white/10"
              />
            </div>
          </div>

          <Button 
            className="w-full bg-primary hover:bg-primary/90 font-display uppercase"
            onClick={handleSave}
          >
            <Save className="w-4 h-4 mr-2" /> Save Changes
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
