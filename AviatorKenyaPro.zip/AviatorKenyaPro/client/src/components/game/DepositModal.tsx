import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState } from "react";
import { toast } from "sonner";
import { Check, Copy, Smartphone, CreditCard } from "lucide-react";

interface DepositModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  currentBalance: number;
}

export function DepositModal({ open, onOpenChange, currentBalance }: DepositModalProps) {
  const [amount, setAmount] = useState("");
  const [phone, setPhone] = useState("");
  const [step, setStep] = useState(1);

  const handleDeposit = () => {
    if (!amount || !phone) return;
    setStep(2);
    // Simulate STK Push
    setTimeout(() => {
      toast.success("STK Push Sent", { 
        description: "Check your phone to complete the transaction." 
      });
      // In a real app, we'd wait for callback. Here we just reset after a delay.
      setTimeout(() => {
        onOpenChange(false);
        setStep(1);
        setAmount("");
      }, 3000);
    }, 1500);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-white/10 text-foreground sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="text-2xl font-display text-primary">Deposit Funds</DialogTitle>
          <DialogDescription>
            Add funds to your account instantly via M-PESA.
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="mpesa" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-black/20">
            <TabsTrigger value="mpesa" className="data-[state=active]:bg-green-600 data-[state=active]:text-white">M-PESA</TabsTrigger>
            <TabsTrigger value="card" disabled className="opacity-50">Card (Coming Soon)</TabsTrigger>
          </TabsList>
          
          <TabsContent value="mpesa" className="space-y-4 mt-4">
            {step === 1 ? (
              <>
                <div className="space-y-2">
                  <Label>Amount (KES)</Label>
                  <div className="grid grid-cols-4 gap-2 mb-2">
                    {[100, 200, 500, 1000].map((val) => (
                      <Button 
                        key={val} 
                        variant="outline" 
                        size="sm"
                        onClick={() => setAmount(val.toString())}
                        className="bg-white/5 border-white/10 hover:bg-white/10 hover:text-primary hover:border-primary/50"
                      >
                        {val}
                      </Button>
                    ))}
                  </div>
                  <Input 
                    type="number" 
                    placeholder="Enter amount" 
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="bg-black/20 border-white/10 text-lg"
                  />
                </div>

                <div className="space-y-2">
                  <Label>M-PESA Phone Number</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">+254</span>
                    <Input 
                      type="tel" 
                      placeholder="712 345 678" 
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="bg-black/20 border-white/10 pl-12"
                    />
                  </div>
                </div>

                <Button 
                  className="w-full bg-green-600 hover:bg-green-700 text-white font-bold uppercase py-6 mt-2"
                  onClick={handleDeposit}
                  disabled={!amount || !phone}
                >
                  Top Up Now
                </Button>
              </>
            ) : (
              <div className="py-8 flex flex-col items-center text-center space-y-4 animate-in fade-in zoom-in">
                <div className="w-16 h-16 rounded-full bg-green-500/20 flex items-center justify-center animate-pulse">
                  <Smartphone className="w-8 h-8 text-green-500" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">Check your phone</h3>
                  <p className="text-sm text-muted-foreground">Enter your M-PESA PIN to complete the deposit of KES {amount}.</p>
                </div>
                <div className="flex gap-2 items-center text-xs text-muted-foreground bg-white/5 px-3 py-1 rounded-full">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full animate-bounce" />
                  Waiting for confirmation...
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
