import { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";
import rocketImage from "@assets/generated_images/futuristic_neon_red_rocket_ship_icon_for_game_multiplier.png";

interface GameCanvasProps {
  gameState: "WAITING" | "FLYING" | "CRASHED";
  multiplier: number;
  countdown: number;
}

export function GameCanvas({ gameState, multiplier, countdown }: GameCanvasProps) {
  const canvasRef = useRef<HTMLDivElement>(null);

  // Calculate rocket position based on multiplier
  // We want a curve that looks exponential but fits in the box
  const getRocketPosition = () => {
    if (gameState === "WAITING") return { x: 0, y: 0 };
    
    // Simple logarithmic scaling for visual curve
    const maxMult = 10; // Visual max
    const progress = Math.min((multiplier - 1) / maxMult, 1);
    
    const x = progress * 80; // 0 to 80%
    const y = Math.pow(progress, 0.8) * 70; // 0 to 70%
    
    return { x, y };
  };

  const pos = getRocketPosition();

  return (
    <div className="relative w-full h-[400px] md:h-[500px] bg-black/40 rounded-3xl border border-white/5 overflow-hidden backdrop-blur-sm shadow-inner shadow-black/50">
      {/* Background Grid */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:40px_40px]"></div>
      
      {/* Axis Labels */}
      <div className="absolute left-0 top-0 bottom-0 w-12 flex flex-col justify-between py-4 px-2 text-xs text-muted-foreground font-mono z-10">
        <span>10.0x</span>
        <span>5.0x</span>
        <span>2.0x</span>
        <span>1.0x</span>
      </div>

      {/* Game Area */}
      <div className="absolute inset-0 left-12 bottom-8" ref={canvasRef}>
        {/* Connection Line (SVG) */}
        {gameState === "FLYING" || gameState === "CRASHED" ? (
          <svg className="absolute inset-0 w-full h-full overflow-visible pointer-events-none">
            <defs>
              <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="var(--color-primary)" stopOpacity="0" />
                <stop offset="100%" stopColor="var(--color-primary)" stopOpacity="1" />
              </linearGradient>
            </defs>
            <path
              d={`M 0 ${canvasRef.current?.clientHeight || 400} Q ${pos.x}% ${canvasRef.current?.clientHeight || 400} ${pos.x}% ${100 - pos.y}%`}
              fill="none"
              stroke="url(#lineGradient)"
              strokeWidth="4"
              className={cn("transition-all duration-100", gameState === "CRASHED" ? "opacity-50 grayscale" : "opacity-100")}
            />
          </svg>
        ) : null}

        {/* Rocket */}
        <div 
          className={cn(
            "absolute w-24 h-24 transition-all duration-100 ease-linear will-change-transform",
            gameState === "WAITING" && "opacity-0",
            gameState === "FLYING" && "opacity-100",
            gameState === "CRASHED" && "opacity-0 scale-150" // Explode/Fade out
          )}
          style={{
            left: `${pos.x}%`,
            bottom: `${pos.y}%`,
            transform: `translate(-20%, 20%) rotate(${gameState === 'FLYING' ? -25 : 0}deg)`
          }}
        >
           <img src={rocketImage} alt="Rocket" className="w-full h-full object-contain drop-shadow-[0_0_15px_rgba(220,20,60,0.6)]" />
           {/* Rocket Engine Particle Effect Mock */}
           {gameState === "FLYING" && (
             <div className="absolute bottom-0 left-0 w-full h-full animate-pulse opacity-50 bg-primary/30 blur-xl rounded-full -z-10"></div>
           )}
        </div>
        
        {/* Explosion Effect */}
        {gameState === "CRASHED" && (
          <div 
            className="absolute w-32 h-32 flex items-center justify-center"
            style={{
              left: `${pos.x}%`,
              bottom: `${pos.y}%`,
              transform: `translate(-20%, 20%)`
            }}
          >
             <div className="text-4xl animate-bounce">💥</div>
             <div className="absolute inset-0 bg-destructive/50 blur-2xl rounded-full animate-ping"></div>
          </div>
        )}
      </div>

      {/* Center Status Display */}
      <div className="absolute inset-0 flex items-center justify-center flex-col pointer-events-none z-20">
        {gameState === "WAITING" && (
          <div className="text-center animate-pulse">
            <div className="text-5xl font-display font-bold text-primary mb-2">NEXT ROUND</div>
            <div className="text-4xl font-mono text-white">{countdown.toFixed(1)}s</div>
            <div className="text-sm text-muted-foreground mt-2 font-ui uppercase tracking-widest">Place your bets</div>
          </div>
        )}

        {gameState === "FLYING" && (
          <div className="text-center">
            <div className="text-7xl md:text-9xl font-display font-black text-white tabular-nums tracking-tighter drop-shadow-[0_0_30px_rgba(255,255,255,0.2)]">
              {multiplier.toFixed(2)}x
            </div>
          </div>
        )}

        {gameState === "CRASHED" && (
          <div className="text-center animate-in zoom-in duration-300">
            <div className="text-2xl font-ui font-bold text-destructive uppercase tracking-widest mb-1">Flew Away</div>
            <div className="text-7xl md:text-9xl font-display font-black text-destructive tabular-nums tracking-tighter drop-shadow-[0_0_30px_rgba(220,38,38,0.4)]">
              {multiplier.toFixed(2)}x
            </div>
          </div>
        )}
      </div>
      
      {/* Loading Bar for Waiting */}
      {gameState === "WAITING" && (
         <div className="absolute bottom-0 left-0 h-2 bg-primary transition-all duration-100 ease-linear" style={{ width: `${(countdown / 5) * 100}%` }} />
      )}
    </div>
  );
}
