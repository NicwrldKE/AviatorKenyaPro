import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Rocket, Lock, Smartphone, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

export default function AuthPage() {
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isRegister, setIsRegister] = useState(false);
  const [, setLocation] = useLocation();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Mock login delay
    setTimeout(() => {
      localStorage.setItem("user_phone", phone);
      setIsLoading(false);
      setLocation("/game");
    }, 1500);
  };

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center bg-background p-4 bg-grid-pattern relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-background to-background pointer-events-none" />
      <div className="absolute top-0 left-0 w-full h-[500px] bg-primary/10 blur-[100px] rounded-full pointer-events-none -translate-y-1/2" />
      
      {/* Logo / Header */}
      <div className="mb-8 text-center relative z-10 animate-in slide-in-from-top duration-700">
        <div className="mx-auto w-20 h-20 rounded-2xl bg-gradient-to-br from-primary to-red-900 flex items-center justify-center mb-4 shadow-2xl shadow-primary/30 rotate-3 hover:rotate-0 transition-transform duration-500">
          <Rocket className="w-10 h-10 text-white fill-white/20" />
        </div>
        <h1 className="text-4xl md:text-5xl font-display font-black text-white tracking-tight uppercase drop-shadow-xl">
          Aviator <span className="text-primary">Pro</span>
        </h1>
        <p className="text-muted-foreground font-ui tracking-wider mt-2 uppercase text-sm">The #1 Realtime Betting Platform in Kenya</p>
      </div>

      <Card className="w-full max-w-md border-white/10 bg-black/40 backdrop-blur-2xl shadow-2xl relative z-10 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent" />
        
        <CardHeader className="space-y-1 text-center pb-2">
          <CardTitle className="text-2xl font-bold text-white">
            {isRegister ? "Create Account" : "Welcome Back"}
          </CardTitle>
          <CardDescription>
            {isRegister ? "Join thousands of winners today" : "Enter your details to continue playing"}
          </CardDescription>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-muted-foreground font-ui uppercase tracking-wider">
                Phone Number
              </label>
              <div className="relative group">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-white font-mono font-bold flex items-center gap-2 border-r border-white/10 pr-2 h-6">
                  <span className="text-xl">🇰🇪</span> +254
                </div>
                <Input 
                  type="tel" 
                  placeholder="712 345 678" 
                  className="pl-28 bg-black/40 border-white/10 focus:border-primary/50 focus:ring-primary/20 h-12 font-mono text-lg text-white transition-all"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  required
                  pattern="[0-9]{9,}"
                />
                <Smartphone className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-muted-foreground font-ui uppercase tracking-wider">
                Password
              </label>
              <div className="relative group">
                <Input 
                  type="password" 
                  placeholder="••••••••" 
                  className="bg-black/40 border-white/10 focus:border-primary/50 focus:ring-primary/20 h-12 font-mono text-lg text-white"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
              </div>
            </div>
            
            <Button 
              type="submit" 
              className="w-full h-14 text-lg font-display font-bold uppercase tracking-widest bg-gradient-to-r from-primary to-red-600 hover:from-primary/90 hover:to-red-600/90 text-white shadow-lg shadow-primary/20 transition-all hover:scale-[1.02] active:scale-[0.98] mt-4"
              disabled={isLoading}
            >
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Processing...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  {isRegister ? "Register Now" : "Login to Play"} <ArrowRight className="w-5 h-5" />
                </div>
              )}
            </Button>
          </form>
        </CardContent>
        
        <CardFooter className="flex flex-col gap-4 bg-white/5 p-6 border-t border-white/5">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>{isRegister ? "Already have an account?" : "New to Aviator Pro?"}</span>
            <button 
              type="button"
              onClick={() => setIsRegister(!isRegister)}
              className="text-primary hover:text-primary/80 font-bold uppercase text-xs tracking-wider"
            >
              {isRegister ? "Login Here" : "Create Account"}
            </button>
          </div>
          
          <div className="w-full flex items-center justify-between text-[10px] text-muted-foreground/50 uppercase tracking-widest font-mono">
            <span>Secure Payments</span>
            <span>Instant Withdrawal</span>
            <span>24/7 Support</span>
          </div>
        </CardFooter>
      </Card>
      
      <div className="mt-8 text-center space-y-2">
         <div className="flex items-center justify-center gap-4 opacity-50 grayscale hover:grayscale-0 transition-all duration-500">
           {/* Mock Payment Logos */}
           <div className="h-8 w-16 bg-white/10 rounded flex items-center justify-center text-[10px] font-bold text-green-500">M-PESA</div>
           <div className="h-8 w-16 bg-white/10 rounded flex items-center justify-center text-[10px] font-bold text-blue-500">AIRTEL</div>
         </div>
      </div>
    </div>
  );
}
