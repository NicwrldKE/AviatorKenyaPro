import { useState, useEffect, useRef } from "react";
import { GameCanvas } from "@/components/game/GameCanvas";
import { BetControls } from "@/components/game/BetControls";
import { BetList } from "@/components/game/BetList";
import { DepositModal } from "@/components/game/DepositModal";
import { ProfileModal } from "@/components/game/ProfileModal";
import { HistoryModal } from "@/components/game/HistoryModal";
import { useLocation } from "wouter";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Wallet, History, User, Settings, LogOut, Menu, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import { Toaster } from "@/components/ui/sonner";
import { toast } from "sonner";

type GameState = "WAITING" | "FLYING" | "CRASHED";

interface Bet {
  user: string;
  amount: number;
  cashoutMult?: number;
  profit?: number;
  isHighRoller?: boolean;
}

export default function GamePage() {
  const [, setLocation] = useLocation();
  const [gameState, setGameState] = useState<GameState>("WAITING");
  const [multiplier, setMultiplier] = useState(1.00);
  const [countdown, setCountdown] = useState(5.0);
  const [balance, setBalance] = useState(15000);
  
  // Modals
  const [isDepositOpen, setIsDepositOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);

  // Round Data
  const [crashPoint, setCrashPoint] = useState(0);
  const [history, setHistory] = useState<number[]>([1.2, 4.5, 2.1, 1.1, 8.4]);
  
  // User Bet State
  const [currentBet, setCurrentBet] = useState<number | null>(null);
  const [autoCashoutAt, setAutoCashoutAt] = useState<number | null>(null);
  const [hasCashedOut, setHasCashedOut] = useState(false);

  // Mock Other Players
  const [activeBets, setActiveBets] = useState<Bet[]>([]);

  // Refs for loop
  const requestRef = useRef<number>(null);
  const startTimeRef = useRef<number>(0);
  const betsIntervalRef = useRef<NodeJS.Timeout>(null);

  // Check Auth
  useEffect(() => {
    const user = localStorage.getItem("user_phone");
    if (!user) setLocation("/");
  }, []);

  // Sync state to localStorage for Admin view
  useEffect(() => {
    localStorage.setItem("game_live_multiplier", multiplier.toFixed(2));
    localStorage.setItem("game_live_state", gameState);
  }, [multiplier, gameState]);

  // Game Loop Control
  useEffect(() => {
    if (gameState === "WAITING") {
      // Start countdown
      const interval = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 0.1) {
            clearInterval(interval);
            startGame();
            return 0;
          }
          return prev - 0.1;
        });
      }, 100);
      
      // Generate bets while waiting
      generateWaitingBets();
      
      return () => {
        clearInterval(interval);
        if (betsIntervalRef.current) clearInterval(betsIntervalRef.current);
      };
    }
  }, [gameState]);

  const generateWaitingBets = () => {
    if (betsIntervalRef.current) clearInterval(betsIntervalRef.current);
    setActiveBets([]); // Clear previous round bets
    
    // Add bets rapidly during waiting phase
    betsIntervalRef.current = setInterval(() => {
      const newBetsCount = Math.floor(Math.random() * 3) + 1;
      const newBets: Bet[] = [];
      
      for (let i = 0; i < newBetsCount; i++) {
        const isHighRoller = Math.random() > 0.9; // 10% chance of high roller
        const amount = isHighRoller 
          ? Math.floor(Math.random() * 10000) + 5000 // 5000 - 15000
          : Math.floor(Math.random() * 900) + 50;    // 50 - 950
        
        newBets.push({
          user: `2547${Math.floor(Math.random() * 90000000 + 10000000)}`,
          amount,
          isHighRoller
        });
      }
      
      setActiveBets(prev => [...newBets, ...prev].slice(0, 100)); // Keep last 100
    }, 200); // Add bets every 200ms
  };

  const startGame = () => {
    // Stop generating new bets
    if (betsIntervalRef.current) clearInterval(betsIntervalRef.current);
    
    // 1. Check Admin Force Crash for next round (Override)
    const adminOverride = localStorage.getItem("admin_next_crash");
    let nextCrash = 0;

    if (adminOverride) {
      nextCrash = parseFloat(adminOverride);
      localStorage.removeItem("admin_next_crash"); // Consume it
      toast.info("Admin Override Active", { className: "text-[10px] opacity-50" });
    } else {
      // 2. Default "Unpredictable" Algorithm
      // Weighted randomness:
      // 50% chance: 1.00x - 2.00x
      // 30% chance: 2.00x - 5.00x
      // 15% chance: 5.00x - 10.00x
      // 5% chance:  10.00x - 100.00x
      const r = Math.random();
      if (r < 0.50) nextCrash = 1.00 + Math.random();
      else if (r < 0.80) nextCrash = 2.00 + (Math.random() * 3.00);
      else if (r < 0.95) nextCrash = 5.00 + (Math.random() * 5.00);
      else nextCrash = 10.00 + (Math.random() * 90.00);
    }

    setCrashPoint(nextCrash);
    setMultiplier(1.00);
    setHasCashedOut(false);
    setGameState("FLYING");
    startTimeRef.current = Date.now();
    
    requestRef.current = requestAnimationFrame(gameTick);
  };

  const gameTick = () => {
    // Check for Admin Force Crash Signal
    if (localStorage.getItem("admin_force_crash") === "true") {
      localStorage.removeItem("admin_force_crash");
      crash(multiplier); // Crash immediately at current multiplier
      return;
    }

    const now = Date.now();
    const elapsed = (now - startTimeRef.current) / 1000;
    
    // Physics: Standard exponential curve
    const newMultiplier = Math.max(1.00, Math.pow(Math.E, 0.06 * elapsed * 2.5));

    if (newMultiplier >= crashPoint) {
      crash(crashPoint);
    } else {
      setMultiplier(newMultiplier);
      
      // Auto Cashout Logic for User
      if (currentBet && autoCashoutAt && newMultiplier >= autoCashoutAt && !hasCashedOut) {
         cashout(newMultiplier);
      }

      // Simulate Cashouts for Bots
      // High rollers cash out early (smart) or super late (greedy)
      setActiveBets(prev => prev.map(bet => {
        if (bet.cashoutMult) return bet; // Already cashed out
        
        // Probability check based on amount and current mult
        // Small bets stay longer, Big bets leave earlier (usually)
        let cashoutChance = 0.02; // Base chance per tick
        
        if (bet.isHighRoller && newMultiplier > 1.5) cashoutChance = 0.1; // High rollers secure bag
        if (newMultiplier > 3.0) cashoutChance = 0.05; // Panic selling starts
        
        if (Math.random() < cashoutChance) {
          return { ...bet, cashoutMult: newMultiplier, profit: bet.amount * newMultiplier };
        }
        return bet;
      }));

      requestRef.current = requestAnimationFrame(gameTick);
    }
  };

  const crash = (finalValue: number) => {
    setMultiplier(finalValue);
    setGameState("CRASHED");
    setHistory(prev => [finalValue, ...prev].slice(0, 20));
    
    if (currentBet && !hasCashedOut) {
      toast.error(`Crashed at ${finalValue.toFixed(2)}x`, { description: `You lost ${currentBet} KES` });
      setCurrentBet(null);
    }

    setTimeout(() => {
      setGameState("WAITING");
      setCountdown(5.0);
      setHasCashedOut(false);
      setCurrentBet(null);
      setAutoCashoutAt(null);
    }, 3000);
  };

  const handleBet = (amount: number, auto: number | null) => {
    if (balance >= amount) {
      setBalance(prev => prev - amount);
      setCurrentBet(amount);
      setAutoCashoutAt(auto);
      toast.success("Bet Placed", { description: `Waiting for round to start...` });
      
      // Add user to active bets list immediately
      const myPhone = localStorage.getItem("user_phone") || "You";
      setActiveBets(prev => [{
        user: myPhone,
        amount: amount,
        isHighRoller: amount >= 5000
      }, ...prev]);

    } else {
      toast.error("Insufficient Balance", { description: "Please deposit funds to continue." });
      setIsDepositOpen(true);
    }
  };

  const cashout = (mult: number = multiplier) => {
    if (currentBet && !hasCashedOut) {
      const winAmount = currentBet * mult;
      setBalance(prev => prev + winAmount);
      setHasCashedOut(true);
      toast.success(`CASHED OUT @ ${mult.toFixed(2)}x`, { 
        description: `You won ${winAmount.toFixed(2)} KES`,
        className: "bg-green-500 border-green-600 text-white"
      });
      
      // Update visual list
      const myPhone = localStorage.getItem("user_phone") || "You";
      setActiveBets(prev => prev.map(b => {
        if (b.user === myPhone && !b.cashoutMult) {
          return { ...b, cashoutMult: mult, profit: winAmount };
        }
        return b;
      }));
    }
  };

  // Sidebar Content
  const SidebarContent = () => (
    <div className="flex flex-col h-full">
       <div className="p-4 flex items-center justify-center border-b border-border bg-card">
           <div className="flex items-center gap-2">
             <div className="w-8 h-8 rounded bg-primary flex items-center justify-center font-display font-bold text-white">AP</div>
             <span className="font-display font-bold text-lg tracking-wider text-primary">AVIATOR PRO</span>
           </div>
        </div>
        
        <div className="p-4 border-b border-border bg-black/20">
          <div className="flex justify-between items-end mb-1">
            <div className="text-xs text-muted-foreground font-ui uppercase tracking-wider">Balance</div>
            <Button 
              size="sm" 
              variant="outline" 
              className="h-6 text-[10px] uppercase border-primary/50 text-primary hover:bg-primary hover:text-white"
              onClick={() => setIsDepositOpen(true)}
            >
              <Plus className="w-3 h-3 mr-1" /> Deposit
            </Button>
          </div>
          <div className="text-2xl font-mono font-bold text-white flex items-center gap-2">
            <Wallet className="w-5 h-5 text-primary" />
            {balance.toLocaleString()} <span className="text-xs text-muted-foreground font-sans">KES</span>
          </div>
        </div>

        <div className="p-2 grid grid-cols-3 gap-2 border-b border-border">
             <Button variant="ghost" size="sm" className="flex flex-col h-auto py-2 gap-1 text-muted-foreground hover:text-primary hover:bg-primary/10" onClick={() => setIsProfileOpen(true)}>
               <User className="w-4 h-4" /> <span className="text-[10px]">Profile</span>
             </Button>
             <Button variant="ghost" size="sm" className="flex flex-col h-auto py-2 gap-1 text-muted-foreground hover:text-primary hover:bg-primary/10" onClick={() => setIsHistoryOpen(true)}>
               <History className="w-4 h-4" /> <span className="text-[10px]">History</span>
             </Button>
             <Button variant="ghost" size="sm" className="flex flex-col h-auto py-2 gap-1 text-muted-foreground hover:text-primary hover:bg-primary/10" onClick={() => toast.info("Settings locked in demo")}>
               <Settings className="w-4 h-4" /> <span className="text-[10px]">Settings</span>
             </Button>
        </div>

        <div className="flex-1 overflow-hidden flex flex-col bg-black/10">
             <div className="p-2 flex justify-between items-center border-b border-white/5">
                <div className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                  Live Bets ({activeBets.length})
                </div>
                <div className="text-[10px] text-muted-foreground">High Rollers: {activeBets.filter(b => b.isHighRoller).length}</div>
             </div>
             <ScrollArea className="flex-1">
               <div className="p-2">
                 <BetList bets={activeBets} />
               </div>
             </ScrollArea>
        </div>

        <div className="p-4 border-t border-border mt-auto bg-card">
          <Button 
            variant="outline" 
            className="w-full gap-2 border-white/10 hover:bg-white/5"
            onClick={() => {
              localStorage.removeItem("user_phone");
              setLocation("/");
            }}
          >
            <LogOut className="w-4 h-4" /> Logout
          </Button>
        </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background flex flex-col md:flex-row overflow-hidden text-foreground font-body">
      <Toaster position="top-center" theme="dark" />
      <DepositModal open={isDepositOpen} onOpenChange={setIsDepositOpen} currentBalance={balance} />
      <ProfileModal open={isProfileOpen} onOpenChange={setIsProfileOpen} />
      <HistoryModal open={isHistoryOpen} onOpenChange={setIsHistoryOpen} />
      
      {/* Desktop Sidebar */}
      <div className="w-64 h-screen border-r border-border hidden md:block z-40 bg-card">
        <SidebarContent />
      </div>

      {/* Mobile Header */}
      <div className="md:hidden h-14 bg-card border-b border-border flex items-center justify-between px-4 z-40">
         <div className="flex items-center gap-2">
             <div className="w-6 h-6 rounded bg-primary flex items-center justify-center font-display font-bold text-white text-xs">AP</div>
             <span className="font-display font-bold text-sm tracking-wider text-primary">AVIATOR PRO</span>
         </div>
         <div className="flex items-center gap-2">
           <div className="text-xs font-mono font-bold text-white">{balance.toLocaleString()}</div>
           <Sheet>
             <SheetTrigger asChild>
               <Button variant="ghost" size="icon"><Menu className="w-5 h-5" /></Button>
             </SheetTrigger>
             <SheetContent side="left" className="p-0 w-72 border-r-border bg-card">
               <SidebarContent />
             </SheetContent>
           </Sheet>
         </div>
      </div>

      {/* Main Game Area */}
      <div className="flex-1 flex flex-col h-[calc(100vh-3.5rem)] md:h-screen overflow-hidden relative bg-grid-pattern">
        {/* Top History Rail */}
        <div className="h-12 bg-black/40 backdrop-blur border-b border-white/5 flex items-center px-4 gap-2 overflow-x-auto no-scrollbar z-10 shrink-0">
          <div className="text-xs font-bold text-muted-foreground uppercase shrink-0 mr-2">History</div>
          {history.map((mult, i) => (
            <div 
              key={i} 
              className={cn(
                "px-2 py-0.5 rounded-full text-xs font-mono font-bold shrink-0 border animate-in fade-in slide-in-from-right duration-500",
                mult >= 10 ? "bg-purple-500/20 text-purple-400 border-purple-500/30" :
                mult >= 2 ? "bg-green-500/20 text-green-400 border-green-500/30" :
                "bg-zinc-800 text-zinc-400 border-zinc-700"
              )}
            >
              {mult.toFixed(2)}x
            </div>
          ))}
        </div>

        {/* Canvas Container */}
        <div className="flex-1 p-2 md:p-6 flex flex-col gap-4 relative overflow-hidden">
          <GameCanvas 
            gameState={gameState} 
            multiplier={multiplier} 
            countdown={countdown}
          />
          
          <BetControls 
            gameState={gameState}
            onBet={handleBet}
            onCashout={() => cashout(multiplier)}
            currentMultiplier={multiplier}
            hasBet={currentBet !== null}
            hasCashedOut={hasCashedOut}
          />
        </div>
      </div>
    </div>
  );
}
