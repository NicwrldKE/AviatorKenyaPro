import { useState, useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export default function AdminPredictor() {
  const [nextCrash, setNextCrash] = useState<string>("");
  const [status, setStatus] = useState("Idle");
  const [forceCrash, setForceCrash] = useState(false);
  const [history, setHistory] = useState<string[]>([]);
  const [, setLocation] = useLocation();

  // Live Monitoring State
  const [liveMultiplier, setLiveMultiplier] = useState("1.00");
  const [liveState, setLiveState] = useState("WAITING");

  useEffect(() => {
    // Poll localStorage to simulate "Live View" (since we don't have a socket)
    const interval = setInterval(() => {
      const m = localStorage.getItem("game_live_multiplier");
      const s = localStorage.getItem("game_live_state");
      if (m) setLiveMultiplier(m);
      if (s) setLiveState(s);
      
      // Reset force crash if game has crashed
      if (s === "CRASHED" && forceCrash) {
        setForceCrash(false);
      }
    }, 100);
    
    return () => clearInterval(interval);
  }, [forceCrash]);

  const handleUpdateCrashPoint = () => {
    if (!nextCrash) return;
    
    // Save to localStorage to communicate with the game tab
    localStorage.setItem("admin_next_crash", nextCrash);
    
    setStatus("Next Round Set: " + nextCrash + "x");
    setHistory(prev => [`Set Next: ${nextCrash}x`, ...prev]);
    setNextCrash("");
    
    toast.success("Crash Point Set", { description: `Next round will crash at ${nextCrash}x` });
  };

  const handleForceCrash = () => {
    if (liveState !== "FLYING") {
      toast.error("Game is not flying");
      return;
    }
    
    localStorage.setItem("admin_force_crash", "true");
    setForceCrash(true);
    setHistory(prev => [`FORCE CRASH TRIGGERED at ${liveMultiplier}x`, ...prev]);
    toast.warning("Crash Signal Sent!");
  };

  return (
    <div className="min-h-screen bg-black p-4 md:p-8 font-mono text-green-500">
      <div className="max-w-4xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="flex justify-between items-end border-b border-green-900/50 pb-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tighter text-white">AVIATOR<span className="text-green-500">_GOD_MODE</span></h1>
            <p className="text-xs text-green-700 mt-1">SYSTEM://ADMIN_ACCESS_GRANTED</p>
          </div>
          <div className="text-right">
             <div className="flex items-center gap-2 text-xs">
               <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
               ONLINE
             </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          
          {/* Live Monitor */}
          <Card className="bg-black border border-green-900 p-6 relative overflow-hidden">
            <div className="absolute top-0 left-0 bg-green-500/10 px-2 py-1 text-[10px] font-bold">LIVE FEED</div>
            
            <div className="flex flex-col items-center justify-center h-64 gap-4">
              <div className={cn(
                "text-6xl font-black tracking-tighter transition-all font-sans",
                liveState === "CRASHED" ? "text-red-600" : "text-white"
              )}>
                {liveMultiplier}x
              </div>
              
              <div className="flex gap-2">
                 <div className={cn("px-3 py-1 rounded text-xs font-bold", liveState === "WAITING" ? "bg-yellow-500/20 text-yellow-500" : "bg-zinc-900 text-zinc-700")}>WAITING</div>
                 <div className={cn("px-3 py-1 rounded text-xs font-bold", liveState === "FLYING" ? "bg-green-500/20 text-green-500 animate-pulse" : "bg-zinc-900 text-zinc-700")}>FLYING</div>
                 <div className={cn("px-3 py-1 rounded text-xs font-bold", liveState === "CRASHED" ? "bg-red-500/20 text-red-500" : "bg-zinc-900 text-zinc-700")}>CRASHED</div>
              </div>
            </div>

            <Button 
              onClick={handleForceCrash}
              disabled={liveState !== "FLYING" || forceCrash}
              className="w-full mt-4 bg-red-600 hover:bg-red-700 text-white font-bold uppercase tracking-widest h-14 border-2 border-red-800 shadow-[0_0_20px_rgba(220,38,38,0.4)]"
            >
              {forceCrash ? "CRASHING..." : "⚠️ FORCE CRASH NOW"}
            </Button>
          </Card>

          {/* Controls */}
          <div className="space-y-6">
             
             {/* Next Round Setter */}
             <Card className="bg-zinc-900/50 border border-white/10 p-6">
               <h3 className="text-white font-bold mb-4 text-sm uppercase opacity-70">Predictor Override</h3>
               <div className="flex gap-4">
                 <Input 
                   type="number" 
                   step="0.01" 
                   placeholder="2.00"
                   value={nextCrash}
                   onChange={(e) => setNextCrash(e.target.value)}
                   className="bg-black border-green-900 text-2xl font-bold text-green-500 h-14"
                 />
                 <Button 
                   onClick={handleUpdateCrashPoint}
                   className="h-14 px-8 bg-green-600 hover:bg-green-700 text-white font-bold"
                 >
                   SET NEXT
                 </Button>
               </div>
               <p className="text-xs text-green-700 mt-2 font-mono">{status}</p>
             </Card>

             {/* Quick Actions */}
             <div className="grid grid-cols-3 gap-2">
                <Button variant="outline" onClick={() => { setNextCrash("1.00"); handleUpdateCrashPoint(); }} className="border-red-900/50 text-red-500 hover:bg-red-950">
                  INSTANT KILL (1.00x)
                </Button>
                <Button variant="outline" onClick={() => { setNextCrash("10.00"); handleUpdateCrashPoint(); }} className="border-green-900/50 text-green-500 hover:bg-green-950">
                  Moon (10x)
                </Button>
                <Button variant="outline" onClick={() => { setNextCrash("2.00"); handleUpdateCrashPoint(); }} className="border-white/10 text-white hover:bg-white/5">
                  Double (2x)
                </Button>
             </div>

             {/* Terminal Logs */}
             <div className="h-48 bg-black border border-green-900/30 p-4 rounded overflow-y-auto font-mono text-xs space-y-1">
                <div className="opacity-50">--- SYSTEM LOGS ---</div>
                {history.map((log, i) => (
                  <div key={i} className="text-green-500/80">&gt; {log}</div>
                ))}
             </div>
          </div>

        </div>
      </div>
    </div>
  );
}
