module.exports = {
  apps: [{
    name: "aviator-pro",
    script: "./dist/index.cjs",
    instances: "max",
    exec_mode: "cluster",
    env: {
      NODE_ENV: "production",
      PORT: 5000
    }
  }]
}
